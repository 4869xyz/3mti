﻿import argparse
import json
import os
import random
from typing import Dict

import numpy as np
import torch
from tqdm import tqdm

try:
    from .config_stage1 import Stage1Config
    from .dataset_remote import build_houston_loaders
    from .losses import total_loss
    from .metrics import compute_classification_metrics
    from .model_stage1 import Stage1HSILiDARDiffusionClassifier
except ImportError:
    from config_stage1 import Stage1Config
    from dataset_remote import build_houston_loaders
    from losses import total_loss
    from metrics import compute_classification_metrics
    from model_stage1 import Stage1HSILiDARDiffusionClassifier


def str2bool(value):
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in {"1", "true", "t", "yes", "y"}:
        return True
    if text in {"0", "false", "f", "no", "n"}:
        return False
    raise argparse.ArgumentTypeError(f"Invalid boolean value: {value}")


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def _to_scalar_dict(loss_dict: Dict[str, torch.Tensor]) -> Dict[str, float]:
    return {k: float(v.detach().item()) for k, v in loss_dict.items()}


def should_evaluate(epoch: int, eval_start_epoch: int, eval_interval: int) -> bool:
    return epoch >= eval_start_epoch and (epoch - eval_start_epoch) % eval_interval == 0


def train_one_epoch(
    model,
    loader,
    optimizer,
    device,
    lambda_align: float,
    lambda_diff: float,
):
    model.train()
    total_samples = 0
    meter = {"loss": 0.0, "loss_cls": 0.0, "loss_align": 0.0, "loss_diff": 0.0}

    pbar = tqdm(loader, desc="Train", leave=False)
    for batch in pbar:
        hsi = batch["hsi"].to(device, non_blocking=True)
        lidar = batch["lidar"].to(device, non_blocking=True)
        labels = batch["label"].to(device, non_blocking=True)

        outputs = model(hsi, lidar)
        losses = total_loss(outputs, labels, lambda_align=lambda_align, lambda_diff=lambda_diff)

        optimizer.zero_grad(set_to_none=True)
        losses["loss"].backward()
        optimizer.step()

        bsz = labels.size(0)
        total_samples += bsz
        scalar_losses = _to_scalar_dict(losses)
        for k in meter:
            meter[k] += scalar_losses[k] * bsz

        pbar.set_postfix(
            loss=f"{scalar_losses['loss']:.4f}",
            cls=f"{scalar_losses['loss_cls']:.4f}",
            align=f"{scalar_losses['loss_align']:.4f}",
            diff=f"{scalar_losses['loss_diff']:.4f}",
        )

    if total_samples == 0:
        return {k: 0.0 for k in meter}
    return {k: v / total_samples for k, v in meter.items()}


@torch.no_grad()
def evaluate_one_epoch(
    model,
    loader,
    device,
    lambda_align: float,
    lambda_diff: float,
    num_classes: int,
):
    model.eval()
    total_samples = 0
    meter = {"loss": 0.0, "loss_cls": 0.0, "loss_align": 0.0, "loss_diff": 0.0}

    all_preds = []
    all_labels = []

    pbar = tqdm(loader, desc="Eval", leave=False)
    for batch in pbar:
        hsi = batch["hsi"].to(device, non_blocking=True)
        lidar = batch["lidar"].to(device, non_blocking=True)
        labels = batch["label"].to(device, non_blocking=True)

        outputs = model(hsi, lidar)
        losses = total_loss(outputs, labels, lambda_align=lambda_align, lambda_diff=lambda_diff)

        preds = outputs["logits"].argmax(dim=1)
        all_preds.append(preds.detach().cpu())
        all_labels.append(labels.detach().cpu())

        bsz = labels.size(0)
        total_samples += bsz
        scalar_losses = _to_scalar_dict(losses)
        for k in meter:
            meter[k] += scalar_losses[k] * bsz

    if total_samples == 0:
        avg_loss = {k: 0.0 for k in meter}
        metrics = {
            "oa": 0.0,
            "aa": 0.0,
            "kappa": 0.0,
            "per_class_acc": np.zeros((num_classes,), dtype=np.float32),
            "confusion_matrix": np.zeros((num_classes, num_classes), dtype=np.int64),
        }
        return avg_loss, metrics

    avg_loss = {k: v / total_samples for k, v in meter.items()}
    y_pred = torch.cat(all_preds, dim=0)
    y_true = torch.cat(all_labels, dim=0)
    metrics = compute_classification_metrics(y_true, y_pred, num_classes=num_classes)
    return avg_loss, metrics


def save_checkpoint(path: str, model, optimizer, epoch: int, best_metrics: Dict[str, float], args) -> None:
    payload = {
        "epoch": epoch,
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "best_metrics": best_metrics,
        "args": vars(args),
    }
    torch.save(payload, path)


def main(args):
    if args.dataset_name.lower() != "houston":
        raise NotImplementedError(
            f"Current Stage1 implementation supports dataset_name='houston' only, got {args.dataset_name}"
        )
    if args.eval_start_epoch < 1:
        raise ValueError(f"eval_start_epoch must be >= 1, got {args.eval_start_epoch}")
    if args.eval_interval < 1:
        raise ValueError(f"eval_interval must be >= 1, got {args.eval_interval}")

    set_seed(args.seed)
    os.makedirs(args.output_dir, exist_ok=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    train_loader, test_loader, meta = build_houston_loaders(
        data_root=args.data_root,
        patch_size=args.patch_size,
        hsi_pca_dim=args.hsi_pca_dim,
        use_pca=args.use_pca,
        train_per_class=args.train_per_class,
        seed=args.seed,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        use_misalign_aug=args.use_misalign_aug,
    )

    print("[Dataset] HSI shape:", meta["hsi_shape"])
    print("[Dataset] LiDAR shape:", meta["lidar_shape"])
    print("[Dataset] Labels shape:", meta["labels_shape"])
    print("[Dataset] Num classes:", meta["num_classes"])
    print("[Dataset] Train samples:", meta["train_samples"])
    print("[Dataset] Test samples:", meta["test_samples"])

    first_batch = next(iter(train_loader))
    print("[Smoke] hsi batch:", tuple(first_batch["hsi"].shape))
    print("[Smoke] lidar batch:", tuple(first_batch["lidar"].shape))
    print("[Smoke] label batch:", tuple(first_batch["label"].shape))

    model = Stage1HSILiDARDiffusionClassifier(
        num_classes=meta["num_classes"],
        latent_dim=args.latent_dim,
        csm_heads=args.csm_heads,
        csm_depth=args.csm_depth,
        dropout=args.dropout,
    ).to(device)

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=args.lr,
        weight_decay=args.weight_decay,
    )

    best_oa = -1.0
    best_kappa = -1.0
    history = []

    for epoch in range(1, args.epochs + 1):
        train_loss = train_one_epoch(
            model,
            train_loader,
            optimizer,
            device,
            lambda_align=args.lambda_align,
            lambda_diff=args.lambda_diff,
        )

        do_eval = should_evaluate(
            epoch=epoch,
            eval_start_epoch=args.eval_start_epoch,
            eval_interval=args.eval_interval,
        )

        if do_eval:
            val_loss, val_metrics = evaluate_one_epoch(
                model,
                test_loader,
                device,
                lambda_align=args.lambda_align,
                lambda_diff=args.lambda_diff,
                num_classes=meta["num_classes"],
            )
            oa = float(val_metrics["oa"])
            aa = float(val_metrics["aa"])
            kappa = float(val_metrics["kappa"])

            log = {
                "epoch": epoch,
                "evaluated": True,
                "train_loss": train_loss,
                "val_loss": val_loss,
                "val_metrics": {
                    "oa": oa,
                    "aa": aa,
                    "kappa": kappa,
                    "per_class_acc": val_metrics["per_class_acc"].tolist(),
                },
            }
            history.append(log)

            print(
                f"Epoch {epoch:03d} | "
                f"train_loss={train_loss['loss']:.4f} "
                f"val_loss={val_loss['loss']:.4f} "
                f"OA={oa:.4f} AA={aa:.4f} Kappa={kappa:.4f}"
            )

            is_better = (oa > best_oa) or (abs(oa - best_oa) < 1e-12 and kappa > best_kappa)
            if is_better:
                best_oa = oa
                best_kappa = kappa
                best_ckpt = os.path.join(args.output_dir, "best.pt")
                save_checkpoint(
                    path=best_ckpt,
                    model=model,
                    optimizer=optimizer,
                    epoch=epoch,
                    best_metrics={"oa": best_oa, "kappa": best_kappa},
                    args=args,
                )
                np.save(
                    os.path.join(args.output_dir, "best_confusion_matrix.npy"),
                    val_metrics["confusion_matrix"],
                )
        else:
            log = {
                "epoch": epoch,
                "evaluated": False,
                "train_loss": train_loss,
                "val_loss": None,
                "val_metrics": None,
            }
            history.append(log)
            print(
                f"Epoch {epoch:03d} | "
                f"train_loss={train_loss['loss']:.4f} "
                f"(skip eval, start={args.eval_start_epoch}, interval={args.eval_interval})"
            )

        last_ckpt = os.path.join(args.output_dir, "last.pt")
        save_checkpoint(
            path=last_ckpt,
            model=model,
            optimizer=optimizer,
            epoch=epoch,
            best_metrics={"oa": best_oa, "kappa": best_kappa},
            args=args,
        )

    with open(os.path.join(args.output_dir, "history.json"), "w", encoding="utf-8") as f:
        json.dump(history, f, ensure_ascii=False, indent=2)

    with open(os.path.join(args.output_dir, "dataset_meta.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)

    print("Training finished.")
    if best_oa < 0:
        print("No evaluation was executed. Please check eval_start_epoch/eval_interval.")
    else:
        print(f"Best OA: {best_oa:.4f}, Best Kappa: {best_kappa:.4f}")


def build_parser() -> argparse.ArgumentParser:
    cfg = Stage1Config()
    parser = argparse.ArgumentParser(description="Stage1 HSI+LiDAR classification training")

    parser.add_argument("--dataset_name", type=str, default=cfg.dataset_name)
    parser.add_argument("--data_root", type=str, default=cfg.data_root)
    parser.add_argument("--patch_size", type=int, default=cfg.patch_size)
    parser.add_argument("--hsi_pca_dim", type=int, default=cfg.hsi_pca_dim)
    parser.add_argument("--use_pca", type=str2bool, default=cfg.use_pca)
    parser.add_argument("--latent_dim", type=int, default=cfg.latent_dim)

    parser.add_argument("--batch_size", type=int, default=cfg.batch_size)
    parser.add_argument("--epochs", type=int, default=cfg.epochs)
    parser.add_argument("--lr", type=float, default=cfg.lr)
    parser.add_argument("--weight_decay", type=float, default=cfg.weight_decay)

    parser.add_argument("--lambda_align", type=float, default=cfg.lambda_align)
    parser.add_argument("--lambda_diff", type=float, default=cfg.lambda_diff)

    parser.add_argument("--use_misalign_aug", type=str2bool, default=cfg.use_misalign_aug)
    parser.add_argument("--eval_start_epoch", type=int, default=cfg.eval_start_epoch)
    parser.add_argument("--eval_interval", type=int, default=cfg.eval_interval)
    parser.add_argument("--train_per_class", type=int, default=cfg.train_per_class)

    parser.add_argument("--csm_heads", type=int, default=cfg.csm_heads)
    parser.add_argument("--csm_depth", type=int, default=cfg.csm_depth)
    parser.add_argument("--dropout", type=float, default=cfg.dropout)

    parser.add_argument("--seed", type=int, default=cfg.seed)
    parser.add_argument("--num_workers", type=int, default=cfg.num_workers)
    parser.add_argument("--output_dir", type=str, default=cfg.output_dir)

    return parser


if __name__ == "__main__":
    parser = build_parser()
    cli_args = parser.parse_args()
    main(cli_args)
