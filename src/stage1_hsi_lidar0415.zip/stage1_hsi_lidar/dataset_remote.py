﻿import os
from typing import Dict, List, Tuple

import numpy as np
import scipy.io as sio
import torch
from sklearn.decomposition import PCA
from torch.utils.data import DataLoader, Dataset

try:
    from .augment import MisalignmentAugment
except ImportError:
    from augment import MisalignmentAugment


def apply_pca(x: np.ndarray, num_components: int) -> np.ndarray:
    if x.ndim != 3:
        raise ValueError(f"Expected HSI cube with shape [H, W, C], got {x.shape}")

    h, w, c = x.shape
    if num_components <= 0:
        raise ValueError(f"num_components must be > 0, got {num_components}")
    if num_components >= c:
        return x.astype(np.float32)

    flat = x.reshape(-1, c)
    pca = PCA(n_components=num_components, whiten=True)
    transformed = pca.fit_transform(flat)
    return transformed.reshape(h, w, num_components).astype(np.float32)


def _pick_first_key(mat_obj: Dict[str, np.ndarray], candidates: List[str]) -> np.ndarray:
    for key in candidates:
        if key in mat_obj:
            return mat_obj[key]
    available = sorted([k for k in mat_obj.keys() if not k.startswith("__")])
    raise KeyError(f"Cannot find keys {candidates}. Available keys: {available}")


def load_houston_dataset(data_root: str = "data") -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    data_dir = os.path.join(data_root, "houston")
    hsi_path = os.path.join(data_dir, "Houston.mat")
    lidar_path = os.path.join(data_dir, "LiDAR.mat")
    gt_path = os.path.join(data_dir, "train_test_gt.mat")

    for p in (hsi_path, lidar_path, gt_path):
        if not os.path.exists(p):
            raise FileNotFoundError(f"Missing required file: {p}")

    hsi_mat = sio.loadmat(hsi_path)
    lidar_mat = sio.loadmat(lidar_path)
    gt_mat = sio.loadmat(gt_path)

    hsi = _pick_first_key(hsi_mat, ["HSI", "hsi", "Houston", "data"])
    lidar = _pick_first_key(lidar_mat, ["LiDAR", "lidar", "DSM", "data"])
    train_mask = _pick_first_key(gt_mat, ["train_data", "train", "TR", "train_gt"])
    test_mask = _pick_first_key(gt_mat, ["test_data", "test", "TE", "test_gt"])

    hsi = np.asarray(hsi, dtype=np.float32)
    lidar = np.asarray(lidar, dtype=np.float32)
    train_mask = np.asarray(train_mask, dtype=np.int64)
    test_mask = np.asarray(test_mask, dtype=np.int64)

    if lidar.ndim == 3:
        if lidar.shape[2] == 1:
            lidar = lidar[..., 0]
        else:
            lidar = lidar.mean(axis=2)

    if hsi.shape[:2] != lidar.shape[:2]:
        raise ValueError(f"HSI and LiDAR spatial size mismatch: {hsi.shape[:2]} vs {lidar.shape[:2]}")

    labels = train_mask + test_mask
    return hsi, lidar, labels


def standardize_hsi(hsi: np.ndarray, eps: float = 1e-6) -> np.ndarray:
    h, w, c = hsi.shape
    flat = hsi.reshape(-1, c)
    mean = flat.mean(axis=0, keepdims=True)
    std = flat.std(axis=0, keepdims=True)
    std = np.maximum(std, eps)
    out = (flat - mean) / std
    return out.reshape(h, w, c).astype(np.float32)


def standardize_lidar(lidar: np.ndarray, eps: float = 1e-6) -> np.ndarray:
    mean = float(lidar.mean())
    std = float(lidar.std())
    std = max(std, eps)
    return ((lidar - mean) / std).astype(np.float32)


def split_fixed_train_test(
    labels: np.ndarray,
    train_per_class: int = 40,
    seed: int = 42,
    ignore_label: int = -1,
) -> Tuple[np.ndarray, np.ndarray, List[int]]:
    rng = np.random.default_rng(seed)
    flat = labels.reshape(-1)
    class_ids = [int(x) for x in np.unique(flat) if int(x) != ignore_label]

    train_indices: List[int] = []
    test_indices: List[int] = []

    for cls_id in class_ids:
        indices = np.flatnonzero(flat == cls_id)
        rng.shuffle(indices)
        n = int(indices.size)

        if n == 0:
            continue
        if n == 1:
            # Fallback for extreme rare class: duplicate one sample to keep both splits non-empty.
            only_idx = int(indices[0])
            train_indices.append(only_idx)
            test_indices.append(only_idx)
            continue

        n_train = min(train_per_class, n - 1)
        n_train = max(1, n_train)

        train_part = indices[:n_train]
        test_part = indices[n_train:]
        if test_part.size == 0:
            test_part = indices[-1:]
            train_part = indices[:-1]

        train_indices.extend(train_part.tolist())
        test_indices.extend(test_part.tolist())

    rng.shuffle(train_indices)
    rng.shuffle(test_indices)

    return (
        np.asarray(train_indices, dtype=np.int64),
        np.asarray(test_indices, dtype=np.int64),
        class_ids,
    )


def flat_indices_to_coords(flat_indices: np.ndarray, width: int) -> np.ndarray:
    rows = flat_indices // width
    cols = flat_indices % width
    return np.stack([rows, cols], axis=1).astype(np.int64)


class RemoteSensingDualModalDataset(Dataset):
    def __init__(
        self,
        hsi_data: np.ndarray,
        lidar_data: np.ndarray,
        labels: np.ndarray,
        coords: np.ndarray,
        class_to_index: Dict[int, int],
        patch_size: int = 11,
        augmenter=None,
    ) -> None:
        super().__init__()
        if patch_size % 2 == 0:
            raise ValueError(f"patch_size must be odd, got {patch_size}")

        self.hsi_data = np.asarray(hsi_data, dtype=np.float32)
        self.lidar_data = np.asarray(lidar_data, dtype=np.float32)
        self.labels = np.asarray(labels, dtype=np.int64)
        self.coords = np.asarray(coords, dtype=np.int64)
        self.class_to_index = class_to_index
        self.patch_size = patch_size
        self.pad = patch_size // 2
        self.augmenter = augmenter

        self.hsi_padded = np.pad(
            self.hsi_data,
            ((self.pad, self.pad), (self.pad, self.pad), (0, 0)),
            mode="reflect",
        )
        self.lidar_padded = np.pad(
            self.lidar_data,
            ((self.pad, self.pad), (self.pad, self.pad)),
            mode="reflect",
        )

    def __len__(self) -> int:
        return int(self.coords.shape[0])

    def __getitem__(self, idx: int):
        row, col = self.coords[idx].tolist()
        row = int(row)
        col = int(col)

        row_p = row + self.pad
        col_p = col + self.pad

        hsi_patch = self.hsi_padded[
            row_p - self.pad : row_p + self.pad + 1,
            col_p - self.pad : col_p + self.pad + 1,
            :,
        ]
        lidar_patch = self.lidar_padded[
            row_p - self.pad : row_p + self.pad + 1,
            col_p - self.pad : col_p + self.pad + 1,
        ]

        hsi_patch = np.transpose(hsi_patch, (2, 0, 1))
        hsi_tensor = torch.from_numpy(np.ascontiguousarray(hsi_patch)).unsqueeze(0).float()
        lidar_tensor = torch.from_numpy(np.ascontiguousarray(lidar_patch)).unsqueeze(0).float()

        if self.augmenter is not None:
            hsi_tensor, lidar_tensor = self.augmenter(hsi_tensor, lidar_tensor)

        raw_label = int(self.labels[row, col])
        if raw_label not in self.class_to_index:
            raise KeyError(f"Label {raw_label} not found in class_to_index")

        label = self.class_to_index[raw_label]

        return {
            "hsi": hsi_tensor,
            "lidar": lidar_tensor,
            "label": torch.tensor(label, dtype=torch.long),
            "coord": torch.tensor([row, col], dtype=torch.long),
        }


def build_houston_loaders(
    data_root: str = "data",
    patch_size: int = 11,
    hsi_pca_dim: int = 30,
    use_pca: bool = True,
    train_per_class: int = 40,
    seed: int = 42,
    batch_size: int = 64,
    num_workers: int = 0,
    use_misalign_aug: bool = True,
):
    hsi_data, lidar_data, labels = load_houston_dataset(data_root=data_root)

    if use_pca:
        hsi_data = apply_pca(hsi_data, hsi_pca_dim)

    hsi_data = standardize_hsi(hsi_data)
    lidar_data = standardize_lidar(lidar_data)

    train_indices, test_indices, class_ids = split_fixed_train_test(
        labels=labels,
        train_per_class=train_per_class,
        seed=seed,
        ignore_label=-1,
    )
    if train_indices.size == 0 or test_indices.size == 0:
        raise RuntimeError("Train/test split is empty. Check labels and train_per_class.")

    h, w = labels.shape
    train_coords = flat_indices_to_coords(train_indices, width=w)
    test_coords = flat_indices_to_coords(test_indices, width=w)

    class_to_index = {cid: i for i, cid in enumerate(class_ids)}

    train_aug = MisalignmentAugment() if use_misalign_aug else None
    dataset_train = RemoteSensingDualModalDataset(
        hsi_data=hsi_data,
        lidar_data=lidar_data,
        labels=labels,
        coords=train_coords,
        class_to_index=class_to_index,
        patch_size=patch_size,
        augmenter=train_aug,
    )
    dataset_test = RemoteSensingDualModalDataset(
        hsi_data=hsi_data,
        lidar_data=lidar_data,
        labels=labels,
        coords=test_coords,
        class_to_index=class_to_index,
        patch_size=patch_size,
        augmenter=None,
    )

    train_loader = DataLoader(
        dataset_train,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True,
    )
    test_loader = DataLoader(
        dataset_test,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True,
    )

    meta = {
        "hsi_shape": tuple(hsi_data.shape),
        "lidar_shape": tuple(lidar_data.shape),
        "labels_shape": tuple(labels.shape),
        "num_classes": len(class_ids),
        "class_ids": class_ids,
        "train_samples": len(dataset_train),
        "test_samples": len(dataset_test),
        "train_per_class": train_per_class,
    }

    return train_loader, test_loader, meta

